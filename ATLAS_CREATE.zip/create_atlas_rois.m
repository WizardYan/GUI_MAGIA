
%% AAL make the cerebellum without vermis. 
mkdir('atlas_rois');
aal_file = 'AAL3v1_1mm.nii';  % adjust path/filename as needed
V = spm_vol(aal_file);
Y = spm_read_vols(V);
roi_indices = 99:112;  % Cerebellum exclude Vermis in AAL3
cerebellum_mask = ismember(Y, roi_indices);

V_mask = V;
V_mask.fname = 'atlas_rois/CER.nii';
V_mask.descrip = 'Cerebellum exclude Vermis (ROI 95–112 from AAL3)';
spm_write_vol(V_mask, cerebellum_mask);


V_mask = V;
V_mask.fname = 'atlas_rois/Cer Exclude Vermis.nii';
V_mask.descrip = 'Cerebellum exclude Vermis (ROI 95–112 from AAL3)';
spm_write_vol(V_mask, cerebellum_mask);


%% HarvardOxford_cortical_subcortical_atlas

% Load the label table
[num, txt, raw] = xlsread('HarvardOxford_Atlas_NewIndex_YCG.xlsx');
T = cell2table(raw(2:end,:), 'VariableNames', raw(1,:));

% Define atlas file names
atlas_files = {
    'HarvardOxford-cort-maxprob-thr25-2mm_YCG.nii', 'atlas_rois';
    'HarvardOxford-sub-maxprob-thr25-2mm_YCG.nii',  'atlas_rois';
};

% Loop over both atlases
for j = 1:size(atlas_files, 1)
    atlas_file = atlas_files{j, 1};
    output_dir = atlas_files{j, 2};
    
    V = spm_vol(atlas_file);
    Y = spm_read_vols(V);
    
    mkdir(output_dir);
    
    for i = 1:height(T)
        idx = T.("New Index")(i);
        name = sprintf('%s %s', T.Nomenclature{i}, T.Hemisphere{i});
        % name = regexprep(name, '\s+', '_');  % replace spaces with underscores
        
        % Skip if this label is not present in the current atlas
        if ~any(Y(:) == idx)
            continue
        end

        % Generate binary mask
        mask = Y == idx;
        
        % Save the NIfTI mask
        V_mask = V;
        V_mask.fname = fullfile(output_dir, sprintf('%s.nii', name));
        % V_mask.fname = fullfile(output_dir, sprintf('%04d_%s.nii', idx, name));
        V_mask.descrip = sprintf('Mask for %s (Index %d)', name, idx);
        spm_write_vol(V_mask, mask);
    end
end







